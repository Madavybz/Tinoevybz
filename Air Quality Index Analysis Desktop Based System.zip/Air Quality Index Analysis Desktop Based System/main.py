from PyQt6.QtWidgets import QApplication,QMessageBox,QMainWindow
from PyQt6 import uic
import sys




class myWindow(QMainWindow):
    def __init__(self):
        super().__init__()




app= QApplication([])
window = myWindow()
window.show()
sys.exit(app.exec())

